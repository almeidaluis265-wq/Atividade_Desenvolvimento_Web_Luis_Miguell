export class ItemPedido {}
