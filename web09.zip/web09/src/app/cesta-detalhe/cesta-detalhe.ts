import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Cesta } from '../model/cesta';

@Component({
  imports: [CommonModule],
  selector: 'app-cesta-detalhe',
  styleUrl: './cesta-detalhe.css',
  templateUrl: './cesta-detalhe.html',
})
export class CestaDetalhe implements OnInit {
  mensagem: string = ""; 
  cesta: Cesta = new Cesta(null); 

  ngOnInit() {
    let json = localStorage.getItem("cesta");
    if (json != null) {
      // Inicializa a classe Cesta com o JSON para herdar as funções do modelo
      this.cesta = new Cesta(json);
      this.mensagem = "";
    } else {
      this.mensagem = "Sua cesta esta vazia!";
    }
  }

  // Função simples para o botão X
  remover(codigo: number) {
    this.cesta.removerItem(codigo); // Remove do array e recalcula o total automaticamente
    localStorage.setItem("cesta", JSON.stringify(this.cesta)); // Salva o novo estado

    // Se esvaziou a lista, exibe a mensagem
    if (this.cesta.itens.length === 0) {
      this.mensagem = "Sua cesta esta vazia!";
    }
  }

  limpar() {
    localStorage.removeItem("cesta");
    location.href = "./promo";
  }
}


